DELIMITER $$
CREATE DEFINER=`dbadmin`@`%` PROCEDURE `OWL_Truncate_EML_Tables`()
BEGIN
    SET foreign_key_checks = 0;
	truncate table CMGT_EML_TRI_APP_MAIL_POLLER;
	truncate table CMGT_EML_TRI_APP_MAIL_POLLER_DOC;
	truncate table CMGT_EML_TRI_ATTACHMENT;
	truncate table CMGT_EML_TRI_MESSAGE;
	truncate table CMGT_EML_TRI_MESSAGE_RECIPIENT;
	truncate table CMGT_EML_TRI_MESSAGE_TEXT;
	truncate table CMGT_EML_TRI_THREAD;
	truncate table CMGT_EML_TRI_THREADSET;
  SET foreign_key_checks = 1;
END$$
DELIMITER ;