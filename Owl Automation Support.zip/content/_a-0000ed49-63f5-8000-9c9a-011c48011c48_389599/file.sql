DELIMITER $$
CREATE DEFINER=`dbadmin`@`%` PROCEDURE `OWL_Delete_Create_Case_Task_Related_Tables`()
BEGIN
    SET foreign_key_checks = 0;
	DELETE FROM `CMGT_CFG_CASE_TYPE` where CASE_TYPE_NAME LIKE "%-SUBMIT-%";
	DELETE FROM `CMGT_TASK` where TITLE LIKE "%-SUBMIT-%";
	DELETE FROM `CMGT_WFL_CFG_REFERENCE_TASK` where NAME_LABEL like "%-SUBMIT-%";
  SET foreign_key_checks = 1;
END$$
DELIMITER ;