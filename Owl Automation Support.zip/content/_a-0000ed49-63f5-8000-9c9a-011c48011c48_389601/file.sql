DELIMITER $$
CREATE DEFINER=`dbadmin`@`%` PROCEDURE `OWL_Delete_ACR_Tables`()
BEGIN
SET foreign_key_checks = 0;
    delete from CMGT_ACR_ASSIGNMENT_RULE where CREATED_ON between NOW() - INTERVAL 7 DAY and NOW();
    delete from CMGT_ACR_RULE_CONDITION where CREATED_ON between NOW() - INTERVAL 7 DAY and NOW();
    delete from CMGT_ACR_RULE_CONDITION_SET where CREATED_ON between NOW() - INTERVAL 7 DAY and NOW();
    delete from CMGT_ACR_USERS_TO_EXCLUDE where CREATED_ON between NOW() - INTERVAL 7 DAY and NOW();
    delete from CMGT_ACR_CASE_ASSIGNMENT_HISTORY where CREATED_ON between NOW() - INTERVAL 7 DAY and NOW();
    SET foreign_key_checks = 1;
    
END$$
DELIMITER ;