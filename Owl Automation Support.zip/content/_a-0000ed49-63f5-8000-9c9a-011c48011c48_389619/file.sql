DELIMITER $$
CREATE DEFINER=`dbadmin`@`%` PROCEDURE `OWL_Truncate_ACR_Tables`()
BEGIN
    SET foreign_key_checks = 0;
    truncate table CMGT_ACR_ASSIGNMENT_RULE;
	truncate table CMGT_ACR_RULE_CONDITION;
	truncate table CMGT_ACR_RULE_CONDITION_SET;
	truncate table CMGT_ACR_USERS_TO_EXCLUDE;
	truncate table CMGT_ACR_CASE_ASSIGNMENT_HISTORY;
  SET foreign_key_checks = 1;
END$$
DELIMITER ;