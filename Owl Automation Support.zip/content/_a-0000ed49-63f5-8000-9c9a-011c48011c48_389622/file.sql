DELIMITER $$
CREATE DEFINER=`dbadmin`@`%` PROCEDURE `OWL_INSERT_EMAIL_RECORDS`()
BEGIN
    SET foreign_key_checks = 0;
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2024 at 10:00 AM
-- Server version: 10.6.16-MariaDB-log
-- PHP Version: 8.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT ;
 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS ;
 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION ;
 SET NAMES utf8mb4 ;

--
-- Database: `Appian`
--

-- --------------------------------------------------------

--
-- Table structure for table `CMGT_EML_TRI_ATTACHMENT`
--

CREATE TABLE IF NOT EXISTS `CMGT_EML_TRI_ATTACHMENT` (
  `ATTACHMENT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key for the CMGT_EML_TRI_Attachment table',
  `APPIAN_DOCUMENT_ID` int(11) DEFAULT NULL COMMENT 'id of the document in Appian',
  `DOCUMENT_NAME` varchar(255) DEFAULT NULL COMMENT 'Name of the attachment',
  `EXTENSION` varchar(255) DEFAULT NULL COMMENT 'File extension of the attachment',
  `SIZE` double DEFAULT NULL COMMENT 'Size of the attachment',
  `MESSAGE_ID` int(11) DEFAULT NULL COMMENT 'foreign key to the CMGT_EML_TRI_Message table',
  `THREAD_ID` int(11) DEFAULT NULL COMMENT 'foreign key to the CMGT_EML_TRI_Thread table',
  PRIMARY KEY (`ATTACHMENT_ID`),
  KEY `MESSAGE_ID` (`MESSAGE_ID`),
  KEY `THREAD_ID` (`THREAD_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='<an attachment on a message>';

--
-- Dumping data for table `CMGT_EML_TRI_ATTACHMENT`
--

INSERT INTO `CMGT_EML_TRI_ATTACHMENT` (`ATTACHMENT_ID`, `APPIAN_DOCUMENT_ID`, `DOCUMENT_NAME`, `EXTENSION`, `SIZE`, `MESSAGE_ID`, `THREAD_ID`) VALUES
(1, 221509, 'Forensic Reports', 'png', 363864, 1, 1),
(2, 221508, 'Financial Statement', 'png', 65735, 1, 1),
(3, 221509, 'Forensic Reports', 'png', 363864, 6, 6),
(4, 221508, 'Financial Statement', 'png', 65735, 6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `CMGT_EML_TRI_MESSAGE`
--

CREATE TABLE IF NOT EXISTS `CMGT_EML_TRI_MESSAGE` (
  `MESSAGE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key for the CMGT_EML_TRI_Message table',
  `THREAD_ID` int(11) DEFAULT NULL COMMENT 'foreign key to the message’s thread',
  `MESSAGE_TEXT_ID` int(11) DEFAULT NULL COMMENT 'fk to the CMGT_EML_TRI_MessageText table where the large text is stored due to record limitations',
  `IS_ACTIVE` tinyint(1) DEFAULT NULL COMMENT 'is the message active',
  `CREATED_BY` varchar(255) DEFAULT NULL COMMENT 'username of the user who sent the message',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'datetime that the message was sent',
  `MODIFIED_BY` varchar(255) DEFAULT NULL COMMENT 'user who last modified the message',
  `MODIFIED_ON` datetime DEFAULT NULL COMMENT 'datetime that the message was last modified',
  PRIMARY KEY (`MESSAGE_ID`),
  UNIQUE KEY `MESSAGE_TEXT_ID` (`MESSAGE_TEXT_ID`),
  KEY `THREAD_ID` (`THREAD_ID`),
  KEY `CREATED_BY` (`CREATED_BY`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='<a rich text message in a thread>';

--
-- Dumping data for table `CMGT_EML_TRI_MESSAGE`
--

INSERT INTO `CMGT_EML_TRI_MESSAGE` (`MESSAGE_ID`, `THREAD_ID`, `MESSAGE_TEXT_ID`, `IS_ACTIVE`, `CREATED_BY`, `CREATED_ON`, `MODIFIED_BY`, `MODIFIED_ON`) VALUES
(1, 1, 1, 1, 'SYSTEM', '2024-09-14 14:10:58', 'SYSTEM', '2024-09-14 14:10:58'),
(2, 1, 2, 1, 'SYSTEM', '2024-09-14 16:10:58', 'SYSTEM', '2024-09-14 16:10:58'),
(3, 1, 3, 1, 'SYSTEM', '2024-09-14 17:11:00', 'SYSTEM', '2024-09-14 17:11:00'),
(4, 1, 4, 1, 'SYSTEM', '2024-09-15 18:11:00', 'SYSTEM', '2024-09-15 18:11:00'),
(5, 1, 5, 1, 'SYSTEM', '2024-09-16 12:00:00', 'SYSTEM', '2024-09-16 12:00:00'),
(6, 2, 6, 1, 'SYSTEM', '2024-09-11 14:10:58', 'SYSTEM', '2024-09-11 14:10:58'),
(7, 2, 7, 1, 'SYSTEM', '2024-09-12 11:10:00', 'SYSTEM', '2024-09-12 11:10:00'),
(8, 2, 8, 1, 'SYSTEM', '2024-09-13 17:11:00', 'SYSTEM', '2024-09-13 17:11:00'),
(9, 2, 9, 1, 'SYSTEM', '2024-09-14 18:11:00', 'SYSTEM', '2024-09-14 18:11:00'),
(10, 2, 10, 1, 'SYSTEM', '2024-09-15 11:00:00', 'SYSTEM', '2024-09-15 11:00:00'),
(11, 3, 11, 1, 'SYSTEM', '2024-09-12 14:10:58', 'SYSTEM', '2024-09-12 14:10:58'),
(12, 3, 12, 1, 'SYSTEM', '2024-09-12 15:10:58', 'SYSTEM', '2024-09-12 15:10:58'),
(13, 4, 13, 1, 'SYSTEM', '2024-09-15 14:10:58', 'SYSTEM', '2024-09-15 14:10:58'),
(14, 4, 14, 1, 'SYSTEM', '2024-09-15 16:10:58', 'SYSTEM', '2024-09-15 16:10:58'),
(15, 4, 15, 1, 'SYSTEM', '2024-09-15 19:10:58', 'SYSTEM', '2024-09-15 19:10:58'),
(16, 5, 16, 1, 'SYSTEM', '2024-09-16 14:10:58', 'SYSTEM', '2024-09-16 14:10:58'),
(17, 5, 17, 1, 'SYSTEM', '2024-09-16 20:10:00', 'SYSTEM', '2024-09-16 20:10:00');

-- --------------------------------------------------------

--
-- Table structure for table `CMGT_EML_TRI_MESSAGE_RECIPIENT`
--

CREATE TABLE IF NOT EXISTS `CMGT_EML_TRI_MESSAGE_RECIPIENT` (
  `MESSAGE_RECIPIENT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key for the CMGT_EML_TRI_MessageRecipient table',
  `MESSAGE_ID` int(11) DEFAULT NULL COMMENT 'foreign key to the CMGT_EML_TRI_Message table',
  `RECIPIENT` varchar(255) DEFAULT NULL COMMENT 'recipient of the message',
  `RECIPIENT_EMAIL` varchar(255) DEFAULT NULL COMMENT 'Email Id of the Recipient',
  `IS_SENDER` tinyint(1) DEFAULT NULL COMMENT 'whether the recipient is the sender of the message',
  PRIMARY KEY (`MESSAGE_RECIPIENT_ID`),
  KEY `MESSAGE_ID` (`MESSAGE_ID`),
  KEY `RECIPIENT` (`RECIPIENT`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='<a recipient of a single message, including metadata of when they read the message>';

--
-- Dumping data for table `CMGT_EML_TRI_MESSAGE_RECIPIENT`
--

INSERT INTO `CMGT_EML_TRI_MESSAGE_RECIPIENT` (`MESSAGE_RECIPIENT_ID`, `MESSAGE_ID`, `RECIPIENT`, `RECIPIENT_EMAIL`, `IS_SENDER`) VALUES
(1, 1, 'John Francis', 'john.francis@mail.com', 0),
(2, 1, 'Emily Rose', 'emily.rose@mailcom', 1),
(3, 3, 'John Francis', 'john.francis@mail.com', 0),
(4, 3, 'Emily Rose', 'emily.rose@mailcom', 1),
(5, 5, 'John Francis', 'john.francis@mail.com', 0),
(6, 5, 'Emily Rose', 'emily.rose@mailcom', 1),
(7, 2, 'John Francis', 'john.francis@mail.com', 1),
(8, 2, 'Emily Rose', 'emily.rose@mailcom', 0),
(9, 4, 'John Francis', 'john.francis@mail.com', 1),
(10, 4, 'Emily Rose', 'emily.rose@mailcom', 0),
(11, 6, 'Michael Lindon', 'michael.lindon@mail.com', 1),
(12, 6, 'Sarah Linda', 'sarah.linda@mailcom', 0),
(13, 8, 'Michael Lindon', 'michael.lindon@mail.com', 1),
(14, 8, 'Sarah Linda', 'sarah.linda@mailcom', 0),
(15, 10, 'Michael Lindon', 'michael.lindon@mail.com', 1),
(16, 10, 'Sarah Linda', 'sarah.linda@mailcom', 0),
(17, 7, 'Michael Lindon', 'michael.lindon@mail.com', 0),
(18, 7, 'Sarah Linda', 'sarah.linda@mailcom', 1),
(19, 9, 'Michael Lindon', 'michael.lindon@mail.com', 0),
(20, 9, 'Sarah Linda', 'sarah.linda@mailcom', 1),
(21, 11, 'Laura Willams', 'laura.williams@mail.com', 1),
(22, 11, 'Dave Peter', 'dave.peter@mailcom', 0),
(23, 12, 'Laura Willams', 'laura.williams@mail.com', 0),
(24, 12, 'Dave Peter', 'dave.peter@mailcom', 1),
(25, 13, 'Jason Joe', 'jason.joe@mail.com', 1),
(26, 13, 'Lena Carol', 'lena.carol@mailcom', 0),
(27, 15, 'Jason Joe', 'jason.joe@mail.com', 1),
(28, 15, 'Lena Carol', 'lena.carol@mailcom', 0),
(29, 14, 'Jason Joe', 'jason.joe@mail.com', 0),
(30, 15, 'Lena Carol', 'lena.carol@mailcom', 1),
(31, 16, 'Sophie Pearl', 'sophie.pearl@mail.com', 1),
(32, 16, 'Tom Cruise', 'tom.cruise@mail.com', 0),
(33, 17, 'Sophie Pearl', 'sophie.pearl@mail.com', 0),
(34, 17, 'Tom Cruise', 'tom.cruise@mail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `CMGT_EML_TRI_MESSAGE_TEXT`
--

CREATE TABLE IF NOT EXISTS `CMGT_EML_TRI_MESSAGE_TEXT` (
  `MESSAGE_TEXT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key for the CMGT_EML_TRI_MessageText table',
  `MESSAGE_ID` int(11) DEFAULT NULL,
  `MESSAGE` longtext DEFAULT NULL COMMENT 'rich text template message',
  PRIMARY KEY (`MESSAGE_TEXT_ID`),
  KEY `CMGT_EML_TRI_MESSAGE_TEXT_ibfk_1` (`MESSAGE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='<templates which can be used when composing a message>';

--
-- Dumping data for table `CMGT_EML_TRI_MESSAGE_TEXT`
--

INSERT INTO `CMGT_EML_TRI_MESSAGE_TEXT` (`MESSAGE_TEXT_ID`, `MESSAGE_ID`, `MESSAGE`) VALUES
(1, 1, 'Hi John\n\nOWL-Link-Case Our office printer has been giving us issues lately. It keeps jamming every few prints. Could you please send someone to take a look?\n\nThanks, Emily'),
(2, 2, 'Hi Emily,\r\n\r\nThank you for reaching out. We can schedule a technician to visit on Thursday. Please let us know if this time works for you.\r\n\r\nBest, John'),
(3, 3, 'Hi John,\r\n\r\nThursday works for us. Please let us know the time and if there\'s anything we should prepare.\r\n\r\nBest, Emily'),
(4, 4, 'Hi Emily,\r\n\r\nThe technician will arrive between 10:00 AM and 12:00 PM. Please ensure the printer is accessible.\r\n\r\nBest regards, John\r\n\r\n'),
(5, 5, 'Hi John,\r\n\r\nThe technician has fixed the printer, and it\'s working fine now. Thanks for the quick response!\r\n\r\nBest, Emily'),
(6, 6, 'Hi Sarah,\n\nOWL-Create-Case My desktop computer won’t boot up this morning. I get a blank screen after the startup logo. Can someone assist?\n\nThanks, Michael'),
(7, 7, 'Hi Michael,\r\n\r\nWe can arrange for a technician to come by today. Does 3:00 PM work for you?\r\n\r\nBest, Sarah'),
(8, 8, 'Hi Sarah,\r\n\r\nYes, 3:00 PM is perfect. I’ll be available at that time.\r\n\r\nThanks, Michael'),
(9, 9, 'Hi Michael,\r\n\r\nThe technician has resolved the issue. Your computer should be working fine now. Let us know if you need further assistance.\r\n\r\nBest regards, Sarah'),
(10, 10, 'Hi Sarah,\r\n\r\nThe computer is up and running. Thanks for the prompt help!\r\n\r\nBest, Michael'),
(11, 11, 'Hello Dave,\r\n\r\nOur network router seems to be malfunctioning. We’re experiencing frequent disconnections. Can you help?\r\n\r\nBest, Laura'),
(12, 12, 'Hi Laura,\n\nOWL-Ignore Tomorrow morning works? Please confirm the time.\n\nBest, Dave'),
(13, 13, 'Hi Lena,\r\n\r\nThe screen on my laptop is cracked and needs to be replaced. Can you advise on the repair process?\r\n\r\nThanks, Jason'),
(14, 14, 'Hi Jason,\r\n\r\nWe can replace the screen. Please drop off the laptop at our service center or we can arrange a pickup. Let us know your preference.\r\n\r\nBest, Lena'),
(15, 15, 'Hi Lena,\r\n\r\nI would prefer to have the laptop picked up. How soon can that be arranged?\r\n\r\nBest, Jason'),
(16, 16, 'Hi Tom,\r\n\r\nMy keyboard has several keys that are not working. I need to get it replaced. Can you guide me through the process?\r\n\r\nBest, Sophie'),
(17, 17, 'Hi Sophie,\r\n\r\nWe can replace the keyboard. Please bring the device to our service center, or we can send a replacement keyboard to you. Which option do you prefer?\r\n\r\nBest, Tom');

-- --------------------------------------------------------

--
-- Table structure for table `CMGT_EML_TRI_THREAD`
--

CREATE TABLE IF NOT EXISTS `CMGT_EML_TRI_THREAD` (
  `THREAD_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key for the CMGT_EML_TRI_Thread table',
  `SUBJECT` varchar(998) DEFAULT NULL COMMENT 'immutable subject of the conversation',
  `THREAD_SET_ID` int(11) DEFAULT NULL COMMENT 'foreign key to the CMGT_EML_TRI_ThreadSet table',
  `THREAD_ORIGINATOR` int(11) DEFAULT NULL COMMENT 'foreign key to the CMGT_EML_TRI_MessageRecipient table',
  `IS_ACTIVE` tinyint(1) DEFAULT NULL COMMENT 'is the thread active',
  `CREATED_BY` varchar(255) DEFAULT NULL COMMENT 'user who created the thread',
  `CREATED_ON` datetime DEFAULT NULL COMMENT 'datetime that the thread was created',
  `MODIFIED_BY` varchar(255) DEFAULT NULL COMMENT 'user who last modified the thread',
  `MODIFIED_ON` datetime DEFAULT NULL COMMENT 'datetime that the thread was last modified',
  `THREAD_STATUS` varchar(255) DEFAULT NULL,
  `OWNER` varchar(255) DEFAULT NULL,
  `THREAD_REASONING` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`THREAD_ID`),
  UNIQUE KEY `THREAD_ORIGINATOR` (`THREAD_ORIGINATOR`),
  KEY `THREAD_SET_ID` (`THREAD_SET_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='<represents a message thread/conversation>';

--
-- Dumping data for table `CMGT_EML_TRI_THREAD`
--

INSERT INTO `CMGT_EML_TRI_THREAD` (`THREAD_ID`, `SUBJECT`, `THREAD_SET_ID`, `THREAD_ORIGINATOR`, `IS_ACTIVE`, `CREATED_BY`, `CREATED_ON`, `MODIFIED_BY`, `MODIFIED_ON`, `THREAD_STATUS`, `OWNER`, `THREAD_REASONING`) VALUES
(1, 'OWL-Link-Case Printer Repair Request', NULL, 2, 1, 'SYSTEM', '2024-09-14 14:10:58', 'SYSTEM', '2024-09-14 14:10:58', 'OPEN', NULL, NULL),
(2, 'OWL-Create-Case Urgent: Computer Issue', NULL, 11, 1, 'SYSTEM', '2024-09-11 14:10:58', 'SYSTEM', '2024-09-11 14:10:58', 'OPEN', NULL, NULL),
(3, 'OWL-Ignore Network Router Issue', NULL, 21, 1, 'SYSTEM', '2024-09-12 14:10:58', 'SYSTEM', '2024-09-12 14:10:58', 'OPEN', NULL, NULL),
(4, 'Laptop Screen Repair', NULL, 25, 1, 'SYSTEM', '2024-09-11 15:10:58', 'SYSTEM', '2024-09-15 14:10:58', 'OPEN', NULL, NULL),
(5, 'Keyboard Replacement Needed', NULL, 31, 1, 'SYSTEM', '2024-09-16 14:10:58', 'SYSTEM', '2024-09-17 09:46:04', 'OPEN', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `CMGT_EML_TRI_THREADSET`
--

CREATE TABLE IF NOT EXISTS `CMGT_EML_TRI_THREADSET` (
  `THREAD_SET_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key for the CMGT_EML_TRI_ThreadSet table',
  `FOLDER_ID` int(11) DEFAULT NULL COMMENT 'id of folder which contains all of the thread folders for the set',
  `CASE_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`THREAD_SET_ID`),
  UNIQUE KEY `CASE_ID` (`CASE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='<table which serves as the link between records and their threads>';

--
-- Constraints for dumped tables
--

--
-- Constraints for table `CMGT_EML_TRI_ATTACHMENT`
--
/*ALTER TABLE `CMGT_EML_TRI_ATTACHMENT`
  ADD CONSTRAINT `CMGT_EML_TRI_ATTACHMENT_ibfk_1` FOREIGN KEY (`MESSAGE_ID`) REFERENCES `CMGT_EML_TRI_MESSAGE` (`MESSAGE_ID`),
  ADD CONSTRAINT `CMGT_EML_TRI_ATTACHMENT_ibfk_2` FOREIGN KEY (`THREAD_ID`) REFERENCES `CMGT_EML_TRI_THREAD` (`THREAD_ID`);

--
-- Constraints for table `CMGT_EML_TRI_MESSAGE`
--
ALTER TABLE `CMGT_EML_TRI_MESSAGE`
  ADD CONSTRAINT `CMGT_EML_TRI_MESSAGE_ibfk_1` FOREIGN KEY (`THREAD_ID`) REFERENCES `CMGT_EML_TRI_THREAD` (`THREAD_ID`),
  ADD CONSTRAINT `CMGT_EML_TRI_MESSAGE_ibfk_2` FOREIGN KEY (`MESSAGE_TEXT_ID`) REFERENCES `CMGT_EML_TRI_MESSAGE_TEXT` (`MESSAGE_TEXT_ID`);

--
-- Constraints for table `CMGT_EML_TRI_MESSAGE_RECIPIENT`
--
ALTER TABLE `CMGT_EML_TRI_MESSAGE_RECIPIENT`
  ADD CONSTRAINT `CMGT_EML_TRI_MESSAGE_RECIPIENT_ibfk_1` FOREIGN KEY (`MESSAGE_ID`) REFERENCES `CMGT_EML_TRI_MESSAGE` (`MESSAGE_ID`);

--
-- Constraints for table `CMGT_EML_TRI_MESSAGE_TEXT`
--
ALTER TABLE `CMGT_EML_TRI_MESSAGE_TEXT`
  ADD CONSTRAINT `CMGT_EML_TRI_MESSAGE_TEXT_ibfk_1` FOREIGN KEY (`MESSAGE_ID`) REFERENCES `CMGT_EML_TRI_MESSAGE` (`MESSAGE_ID`);

--
-- Constraints for table `CMGT_EML_TRI_THREAD`
--
ALTER TABLE `CMGT_EML_TRI_THREAD`
  ADD CONSTRAINT `CMGT_EML_TRI_THREAD_ibfk_1` FOREIGN KEY (`THREAD_SET_ID`) REFERENCES `CMGT_EML_TRI_THREADSET` (`THREAD_SET_ID`),
  ADD CONSTRAINT `CMGT_EML_TRI_THREAD_ibfk_2` FOREIGN KEY (`THREAD_ORIGINATOR`) REFERENCES `CMGT_EML_TRI_MESSAGE_RECIPIENT` (`MESSAGE_RECIPIENT_ID`);
COMMIT;*/

 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT ;
 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS ;
 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION ;

  SET foreign_key_checks = 1;
END$$
DELIMITER ;